# Star Trace

This version is currently in construction and not ready for use. See past commits for previous working
 releases or check back later (1 week or so).

### ToDo List

- [ ] Add documentation
- [ ] Add tests
- [ ] Add docstrings
- [ ] Add comments
- [ ] Add more examples